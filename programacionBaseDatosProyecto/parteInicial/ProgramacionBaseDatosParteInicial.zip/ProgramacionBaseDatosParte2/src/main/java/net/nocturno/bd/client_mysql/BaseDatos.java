/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package net.nocturno.bd.client_mysql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author grafeno30
 */
public class BaseDatos {
    
     private final String URL;
     private final String user;
     private final String clave;
     private final String nombreBD;
               
     Connection conexion;
     
     public BaseDatos(String URL, String user, String clave, String nombreBD){
         this.URL = URL;
         this.user = user;
         this.clave = clave;
         this.nombreBD = nombreBD;
     }
     
     public void Conecta(){
        try {
            conexion = DriverManager.getConnection(URL+nombreBD, user, clave);
        } catch (SQLException ex) {
            Logger.getLogger(principal.class.getName()).log(Level.SEVERE, null, ex);
        }
         
     }
     
     public void Desconecta(){
         try {
             conexion.close();
         } catch (SQLException ex) {
             Logger.getLogger(BaseDatos.class.getName()).log(Level.SEVERE, null, ex);
         }
     }
     
     
    public String[] ejecutaConsulta(String consulta){
        
    String[] resultado = null;    
        
    try {
        Statement s = conexion.createStatement();
        ResultSet rs = s.executeQuery(consulta);
        
        int i = 0;
        while (rs.next()) {
           i++;
         }
        
        resultado = new String[i];
        
        rs = s.executeQuery(consulta);
        i=0;
        while (rs.next()) {
        
           resultado[i] =
           "| " + rs.getInt(1) + " | " + 
           rs.getString(2) + "|" + 
           rs.getString(3)  + " | " + 
           rs.getString(4)  + " | " + 
           rs.getString(5)  + " | " + 
           rs.getString(6)  + " | " + 
           rs.getString(7);
           i++;
         }
    } 
    catch (SQLException e) {
        System.err.println(e.toString());
     }
    
    return resultado;
    
    } 
    
}
